package JavaCodingT_0410.ex03;

public enum Position {
	부장,
	차장,
	과장,
	대리,
	사원;

}
