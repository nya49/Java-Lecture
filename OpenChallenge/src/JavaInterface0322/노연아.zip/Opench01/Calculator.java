package JavaInterface.Opench01;

public interface Calculator {

	public abstract int add(int a, int b);
	public abstract int subtract(int a, int b);
	public abstract int multiply(int a, int b);
}
