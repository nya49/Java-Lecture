package JavaInterface.Opench03;

public interface MySort {

	public abstract String[] sort(String[] strArray);
	public abstract String[] sort(String[] strArray, boolean descOrder);
	
}
