package Exercise.ex03;

public interface Soundable {
	String sound();
}
