package Exercise.ex03;

public class Dog implements Soundable {

	@Override
	public String sound() {
		return "멍멍";
		
	}
	
	
}
