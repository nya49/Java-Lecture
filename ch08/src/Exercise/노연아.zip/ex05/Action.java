package Exercise.ex05;

public interface Action {
	void work();
}
