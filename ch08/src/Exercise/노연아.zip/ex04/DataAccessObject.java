package Exercise.ex04;

public interface DataAccessObject {
	
	void select();
	void insert();
	void update();
	void delete();

}
