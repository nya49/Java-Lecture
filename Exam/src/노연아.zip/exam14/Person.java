package exam14;


public class Person {

}
