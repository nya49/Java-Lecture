package ClassEx.OpenChallenge2;

public class SongEx {

	public static void main(String[] args) {
		Song mySong = new Song("Love of My Life", "Queen", "A Night at the Oper", "프레디 머큐리", "1975년", 9);
		mySong.show();

	}

}
