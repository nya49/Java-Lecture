package Exercise.ex16;

public class Printer {
	
	public void println(int a) {
		System.out.println(a);
	}
	
	public void println(boolean a) {
		System.out.println(a);
		}
	
	public void println(double a) {
		System.out.println(a);
	}
	
	public void println(String a) {
		System.out.println(a);
	}
}
