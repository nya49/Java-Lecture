package Exercise.ex17;

public class Printer {
	
	static void println(int a) {
		System.out.println(a);
	}
	
	static void println(boolean a) {
		System.out.println(a);
		}
	
	static void println(double a) {
		System.out.println(a);
	}
	
	static void println(String a) {
		System.out.println(a);
	}
}
