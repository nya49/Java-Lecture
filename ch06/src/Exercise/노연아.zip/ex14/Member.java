package Exercise.ex14;

public class Member {
	Member(String name, String id){
	}
}
