package exercise;

public class Exercise06 {

	public static void main(String[] args) {
		int legthTop = 5;
		int lengthBottom = 10;
		int height = 7;
		double area = (0.5*(legthTop+lengthBottom)*height);
		System.out.println(area);

	}

}
